#!/usr/bin/env python
# coding: utf-8

# # Datasets

# In[28]:


import pandas as pd
import tsemodule5 as tm5
#url="C:/Users/Ateeq/Downloads/Iran.Khodro(1).csv"
#khodro=pd.read_csv(url, parse_dates=True, index_col="<DTYYYYMMDD>")[::-1]
khodro=tm5.stock("خودرو", value=250, standard=True)[::-1]
khodro.tail(100)


# # Visulation 

# In[30]:


import matplotlib.dates as mdates
import matplotlib.pyplot as plt 
import datetime as dt

x_dates=khodro.index.values
plt.figure(figsize=(15,10))

plt.plot(x_dates,khodro["High"],label="High")
plt.plot(x_dates,khodro["Low"],label="Low")
plt.xlabel("Time scale")
plt.ylabel("scaled rial")
plt.legend()
plt.gcf().autofmt_xdate()
plt.show()


# In[31]:


import matplotlib.pyplot as plt 
import pandas as pd 
import numpy as np
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense
from tensorflow.keras.layers import  LSTM
from tensorflow.keras.layers import  Dropout
from tensorflow.keras.layers import *
from tensorflow.keras.callbacks import EarlyStopping

from sklearn.preprocessing import MinMaxScaler , StandardScaler 
from sklearn.metrics import mean_squared_error 
from sklearn.metrics import mean_absolute_percentage_error
from sklearn.model_selection import train_test_split
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import mean_squared_error


# In[33]:


target_y=khodro["Close"]
x_feat=khodro.iloc[:,1:3]


# In[34]:


#Feature scaling 
sc=StandardScaler()
x_ft=sc.fit_transform(x_feat.values)
x_ft=pd.DataFrame(columns=x_feat.columns, data=x_ft, index=x_feat.index)


# In[35]:


x_ft


# # LSTM_function

# In[36]:


def lstm_split (data,n_steps):
    X,y=[],[]
    for i in range(len(data)-n_steps+1):
        X.append(data[i:i+n_steps,:-1])
        y.append(data[i+n_steps-1,-1])
        
    return np.array(X),np.array(y) 
   


# # Train and Test Sets for Stock Price  Prediction
# 

# In[37]:


x1 ,y1= lstm_split(khodro.values, n_steps=2)

train_split=0.8
split_idx=int(np.ceil(len(x1)*train_split))
data_index=khodro.index

x_train , x_test=x1[1:],x1[:1]
y_train , y_test=y1[:split_idx],y1[split_idx:]
x_train_date ,y_train_date=data_index[:split_idx], data_index[split_idx:]

print(x1.shape,x_train.shape,x_test.shape,y_test.shape)


# In[38]:


x_train


# # Building the LSTM model

# In[39]:


lstm=Sequential()
lstm.add(LSTM(32, input_shape=(x_train.shape[1],x_train.shape[2]),
             activation='relu',return_sequences=True))
lstm.add(Dense(1))
lstm.compile(loss="MSE", optimizer='adam')
lstm.summary()


# # Now we can fit this simple model to the training data.
# 
# 

# In[40]:


tf.convert_to_tensor(x_train, dtype=tf.float32)


# In[49]:


import tensorflow as tf
#history=lstm.fit(x_train,y_train,epochs=35,batch_size=4,verbose=2,shuffle=False)


# # Performance Evaluation on Test Set
# 

# In[50]:


y_pred=lstm.predict(x_test)
y_pred


# In[ ]:




